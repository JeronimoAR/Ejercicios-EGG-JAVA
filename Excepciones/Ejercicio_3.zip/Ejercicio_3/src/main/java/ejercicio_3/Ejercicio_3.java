package ejercicio_3;

import java.util.Scanner;
import ejercicio_3.Entidad.DivisionNumero;

public class Ejercicio_3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese dos numeros");
        Integer num1 = sc.nextInt(),num2 = sc.nextInt();
        
        DivisionNumero division = new DivisionNumero();
        
        try{
            division.Division(num1, num2);
        }catch(ArithmeticException e){
            System.out.println("Error trataste de divir entre 0 " + e.fillInStackTrace());
        }finally{
            System.out.println("FIN.");
        }
    }
}
