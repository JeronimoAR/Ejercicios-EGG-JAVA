package ejercicio_3.Entidad;

public class DivisionNumero {

    public DivisionNumero() {
    }
    
    public int Division(int num1, int num2){
        return num1 / num2;
    }
}
