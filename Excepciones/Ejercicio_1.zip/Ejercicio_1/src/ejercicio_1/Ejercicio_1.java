package ejercicio_1;

import ejercicio_7.Entidad.Persona;

public class Ejercicio_1 {

    public static void main(String[] args) {
        Persona persona = null;
        
        try{
            persona.esMayorDeEdad();
        }catch(Exception e){
            System.out.println("Error " + e.getMessage());
        }
    }
    
}
