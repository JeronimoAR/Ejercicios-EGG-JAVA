package ejercicio_5;

import java.util.*;

public class Ejercicio_5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        Random r = new Random();

        int num = r.nextInt(500), op, contF = 0;
        System.out.println("Ingrese un numero para intenar adivinarlo: ");
        try {
            do {
                System.out.println("Ingrese el numero: ");
                op = sc.nextInt();
                if (op == num) {
                    System.out.println("Correcto el numero escondido es: " + op);
                } else if (num < op) {
                    System.out.println("EL numero escondido es menor que: " + op);
                    contF += 1;
                } else if (num > op) {
                    System.out.println("El numero escondido es mayor que: " + op);
                    contF += 1;
                }
            } while (op != num);
        } catch (InputMismatchException e) {
            System.out.println("Error solo se pueden ingresar numeros");
            contF += 1;
        } finally {
            System.out.println("Intentos: " + contF);
        }
    }
}
