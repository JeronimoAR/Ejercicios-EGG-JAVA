package ejercicio_2;

import ejercicio_2.Entidad.ErrorComoAaron;

public class Ejercicio_2 {

    public static void main(String[] args) {
        ErrorComoAaron error = new ErrorComoAaron();
        error.llenarLista();
        try{
            int i = error.getLista()[6];
        }catch(ArrayIndexOutOfBoundsException e){
            System.out.println("Error " + e.fillInStackTrace());
        }finally{
            System.out.println("FIN");
        }
    }
}
