package ejercicio_2.Entidad;

public class ErrorComoAaron {
    public int[] lista = new int[5];

    public ErrorComoAaron() {
    }

    public int[] getLista() {
        return lista;
    }

    public void setLista(int[] lista) {
        this.lista = lista;
    }

    
    
    public void llenarLista(){
        for (int i = 0; i < 5; i++) {
            lista[i] = i;
        }
    }
}
