package ejercicio_4;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Ejercicio_4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        
        try{
            System.out.println("Ingrese un numero: ");
            int i = sc.nextInt();
            String text = "6";
            int j = Integer.parseInt(text);
            int x = 4 / 2;
        }catch(InputMismatchException i){
            System.out.println("Error en el ingreso de teclado: " + i.fillInStackTrace());
        }catch(NumberFormatException n){
            System.out.println("Error en el formato que se debe transformar en entero: " + n.fillInStackTrace());
        }catch(ArithmeticException a){
            System.out.println("Error Division: " + a.fillInStackTrace());
        }finally{
            System.out.println("FIN.");
        }
        
    }
}
