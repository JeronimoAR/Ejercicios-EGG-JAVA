package Ejercicio_1;

import Ejercicio_1.Clases.Libro;
import java.util.Scanner;

public class Ejercicio_1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Libro lib1 = new Libro();
        System.out.println("Ingresa el ISBN");
        lib1.ISBN = sc.nextLine();
        System.out.println("Ingresa el autor");
        lib1.autor = sc.nextLine();
        System.out.println("Ingresa el titulo");
        lib1.titulo = sc.nextLine();
        System.out.println("Ingresa el numero de paginas");
        lib1.paginas = sc.nextInt();

        lib1.mostrarLibro();

    }

}
