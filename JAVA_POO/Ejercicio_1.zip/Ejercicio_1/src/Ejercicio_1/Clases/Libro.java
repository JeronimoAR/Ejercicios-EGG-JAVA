package Ejercicio_1.Clases;

public class Libro {

    public String ISBN;
    public String autor;
    public String titulo;
    public int paginas;

    public Libro() {

    }

    public Libro(String ISBN, String autor, String titulo, int paginas) {
        this.ISBN = ISBN;
        this.autor = autor;
        this.paginas = paginas;
        this.titulo = titulo;
    }

    public void mostrarLibro() {
        System.out.println("El ISBN es: " + ISBN);
        System.out.println("El aoutor es: " + autor);
        System.out.println("El titulo es: " + titulo);
        System.out.println("El numro de paginas es: " + paginas);
    }

}
