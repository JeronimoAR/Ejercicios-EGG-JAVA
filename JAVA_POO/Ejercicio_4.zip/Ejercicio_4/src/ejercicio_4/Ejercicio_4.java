package ejercicio_4;

import ejercicio_4.Services.Services;

public class Ejercicio_4 {

    public static void main(String[] args) {
        Services rec = new Services(); 
        rec.crearRec();
        rec.mostrarRec();
        rec.superficie();
        rec.perimetro();
    }

}
