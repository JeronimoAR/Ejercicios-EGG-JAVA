package extra_6;

import extra_6.Services.Servicio;

public class Extra_6 {

    public static void main(String[] args) {
        Servicio juego = new Servicio();
        juego.juego();
    }
    
}
