package extra_2;

import extra_2.Services.Service;

public class Extra_2 {

    public static void main(String[] args) {
        Service punto = new Service();
        punto.crearPuntos();
        punto.calcularDistancia();
    }
    
}
