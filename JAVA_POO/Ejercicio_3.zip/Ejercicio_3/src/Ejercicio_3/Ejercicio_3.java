package Ejercicio_3;

import Ejercicio_3.Entidad.Services.Services;
import java.util.Scanner;

public class Ejercicio_3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Services num = new Services();
        int op;
        boolean flag = true;
        num.crearOp();
        do{
            System.out.println("||||");
            System.out.println("Menu");
            System.out.println("1.Sumar \n2.Restar \n3.Multiplicar \n4.Dividir \n5.Salir");
            op = sc.nextInt();
            switch(op){
                case 1:
                    System.out.println("La suma de los numeros es: " + num.sumar());
                    break;
                case 2:
                    System.out.println("La resta de los numeros es: " + num.restar());
                    break;
                case 3:
                    System.out.println("La multiplicacion de los numeros es: " + num.multiplicar());
                    break;
                case 4:
                    System.out.println("La divicion de los numeros es: " + num.dividir());
                    break;
                case 5:
                    System.out.println("---Saliendo---");
                    flag = false;
                    break;
                default:
                    System.out.println("-----------------");
                    System.out.println("Ingreso no valido");
                    System.out.println("-----------------");
            }
            
            
        }while(flag == true);
    }

}
