package Ejercicio_3.Entidad.Services;

import Ejercicio_3.Entidad.Op;
import java.util.Scanner;

public class Services {
    Scanner sc = new Scanner(System.in);
    Op num = new Op();
    boolean flag = true;
    int suma,resta,mul,div;
    public void crearOp(){
        System.out.println("Ingresa el primer numero");
        num.setNum1(sc.nextInt());
        System.out.println("Ingresa el segundo numero");
        num.setNum2(sc.nextInt());
    }    
    
    public int sumar() {
        suma = num.getNum1() + num.getNum2();
        return suma;
    }

    public int restar() {
        resta = num.getNum1() - num.getNum2();
        return resta;
    }
    
    public int multiplicar() {
        if (num.getNum1() != 0 && num.getNum2() != 0) {
            mul = num.getNum1() * num.getNum2();
        }else{
            System.out.println("Estas intentando multiplicar por 0");
            mul = 0;
        }
        return mul;
    }
    
    public int dividir(){
        if (num.getNum1() != 0 && num.getNum2() != 0) {
            div = (int)num.getNum1() / num.getNum2();
        }else{
            System.out.println("Estas intentando dividir por 0");
            div = 0;
        }
        return div;
    }
    
}
