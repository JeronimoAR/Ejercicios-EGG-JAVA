package extra_1;

import extra_1.Services.PersonaServicio;

public class Extra_1 {

    public static void main(String[] args) {
        PersonaServicio obj = new PersonaServicio();
        obj.menu();
    }
    
}
