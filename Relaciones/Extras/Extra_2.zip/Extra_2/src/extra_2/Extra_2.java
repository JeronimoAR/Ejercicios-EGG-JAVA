package extra_2;

import extra_2.Services.ServicioSala;

public class Extra_2 {

    public static void main(String[] args) {
       ServicioSala sala = new ServicioSala();
       sala.menu();
    }

}
