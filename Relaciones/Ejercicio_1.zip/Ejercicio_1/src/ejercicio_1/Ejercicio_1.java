package ejercicio_1;

import ejercicio_1.Services.PersonaServicio;

public class Ejercicio_1 {

    public static void main(String[] args) {
        PersonaServicio obj = new PersonaServicio();
        obj.menu();
    }
    
}
