/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manos.a.la.obra.pkg11;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class ManosALaObra11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       Scanner sc = new Scanner(System.in);
       String frase;
       System.out.println("Ingresa una frase que la voy a codificar");
       frase = sc.nextLine();
        System.out.println(frase);
       System.out.println("---Encriptando---");
       System.out.println(cript(frase));
    }
public static String cript(String frase){
    int cont = frase.length();
    String encript,encriptado;
    encriptado = "";
    System.out.println(cont);
    for (int i = 0; i < cont; i++){
        encript = frase.substring(i,i + 1);
        switch (encript.toLowerCase()){
            case "a":
                encript = "@";
                break;
            case "e":
                encript = "#";
                break;
            case "i":
                encript = "$";
                break;
            case "o":
                encript = "%";
                break;
            case "u":
                encript = "*";
                break;
        }
        encriptado = encriptado + encript;
    }
    return encriptado;
}
}
