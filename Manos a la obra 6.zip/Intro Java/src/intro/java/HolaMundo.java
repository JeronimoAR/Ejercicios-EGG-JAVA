/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package intro.java;

import java.util.Scanner;

/**
 *
 * @author jeron
 */
public class HolaMundo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Scanner leer = new Scanner(System.in);
    int num1,num2;
    System.out.println("Ingresa dos numeros Enteros");
    num1 = leer.nextInt();
    num2 = leer.nextInt();
    if (num1 == 25 && num2 == 25){
        System.out.println("Ambos numeros son iguales a 25");
    }else if (num1 == 25 || num2 == 25){
        System.out.println("Solo un numero es igual a 25");
    }else{
        System.out.println("Ninguno es igual a 25");
    }
    }
}
