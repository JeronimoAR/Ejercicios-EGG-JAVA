/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manos_a_la_obra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class ManosALaObra12 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num1,num2;
        System.out.println("Ingresa un numero");
        num1 = sc.nextInt();
        System.out.println("Ingresa otro para ver si es multiplo del anterior");
        num2 = sc.nextInt();
        esMultiplo(num1,num2);
    }
    public static void esMultiplo(int num1,int num2){
        boolean flag;
        if (num2 % num1 == 0){
        flag = true;
        }else{
        flag = false;
        }
        System.out.println(flag);
    }
}
