/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manos_a_la_obra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class ManosALaObra9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num,suma,cont;
        cont = 1;
        suma = 0;
        System.out.println("Ingresa 20 numeros");
        num = sc.nextInt();
        while (cont < 20){
            if (num < 0){
                continue;
            }else if (num == 0){
                System.out.println("Se capturo el numero 0");
                break;
            }
            else{
                suma = suma + num;
                num = sc.nextInt();
                cont = cont + 1;
            }
        }
        System.out.println("La suma de los valores es: " + suma);
    }
    
}
