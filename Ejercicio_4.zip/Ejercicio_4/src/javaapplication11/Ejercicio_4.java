/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication11;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Ejercicio_4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int celcius;
        double fahrenheit;
        System.out.println("Ingresa grados celcius");
        celcius = sc.nextInt();
        fahrenheit = 32 + (9*celcius/5);
        System.out.println("Eso en grados farnheit es: " + fahrenheit);
    }
    
}
