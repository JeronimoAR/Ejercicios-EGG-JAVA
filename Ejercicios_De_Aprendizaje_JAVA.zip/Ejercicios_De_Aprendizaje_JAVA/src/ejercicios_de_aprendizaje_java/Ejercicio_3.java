/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_de_aprendizaje_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Ejercicio_3 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String frase;
        System.out.println("Dame una frase");
        System.out.println("--------------");
        frase = sc.nextLine();
        System.out.println(frase.toUpperCase());
        System.out.println("--------------");
        System.out.println(frase.toLowerCase());
    }
}
