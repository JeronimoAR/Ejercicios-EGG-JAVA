package ejercicio_5;

import java.util.*;

public class Ejercicio_5 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        TreeSet<String> paises = new TreeSet();
        String op, pais;
        boolean flag = false;

        do {
            System.out.println("Ingrese el nombre del pais:");
            paises.add(sc.nextLine());
            System.out.println("Desea seguir ingresando paises?(S/N)");
            op = sc.nextLine();
        } while (op.equalsIgnoreCase("s"));

        System.out.println("----------------------------------------");
        System.out.println("Paises Ingresados:");
        System.out.println(paises);


        do {
            flag = false;
            System.out.println("Ingrese un pais para eliminar");
            pais = sc.nextLine();
            Iterator<String> it = paises.iterator();
            while (it.hasNext()) {
                if (it.next().equals(pais)) {
                    it.remove();
                    System.out.println("El pais se elimino correctamente");
                    flag = true;
                }
            }
            if (flag == false) {
                System.out.println("El pais no se encontró");
            }
            System.out.println("Desea seguir Eliminando paises?(S/N)");
            op = sc.nextLine();
        } while (op.equalsIgnoreCase("s"));

        System.out.println("----------------------------------------");
        System.out.println("Paises Ingresados:");
        System.out.println(paises);

    }

}
