package manos_la_obra.Entidad;

import java.util.*;

public class Libros {

    private String titulo;
    private String año;

    public String getAño() {
        return año;
    }

    public void setAño(String año) {
        this.año = año;
    }

    public Libros() {
    }

    public Libros(String año) {
        this.año = año;
    }

    public Libros(String titulo, String año) {
        this.titulo = titulo;
        this.año = año;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String toString() {
        return "Libro{Titulo = " + titulo + "}"; //To change body of generated methods, choose Tools | Templates.
    }

    public static Comparator<Libros> compararAño = new Comparator<Libros>() {
        @Override
        public int compare(Libros l1, Libros l2) {
            return l1.getAño().compareTo(l2.getAño());
        }
    };
    
}
