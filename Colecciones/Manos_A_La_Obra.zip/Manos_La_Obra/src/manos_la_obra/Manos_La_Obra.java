package manos_la_obra;

import manos_la_obra.Entidad.Libros;
import java.util.*;

public class Manos_La_Obra {

    public static void main(String[] args) {
        ArrayList<Integer> numeros = new ArrayList();
        TreeSet<String> palabras = new TreeSet();
        HashMap<Integer, String> personas = new HashMap();
        int n = 0;
        String[] nombres = {"Jero", "Sebastian", "Leandro", "Jacobo", "Jenny"};

        for (int i = 0; i < 5; i++) {
            n = (int) (Math.random() * 1000000);
            numeros.add(n);
            palabras.add(nombres[i]);
            personas.put(n, nombres[i]);
        }
        System.out.println(numeros);
        System.out.println(palabras);
        for (Map.Entry<Integer, String> entry : personas.entrySet()) {
            System.out.println("DNI: " + entry.getKey() + " Nombre: " + entry.getValue());
        }
        // Para ver las llaves y valores en una sola linea System.out.println("DNI: " + personas.keySet() + " Nombre: " + personas.values());
        numeros.remove(4);
        palabras.remove("Jenny");
        personas.remove(n);

        System.out.println("---------------");
        System.out.println("Colecciones con el ultimo valor borrado");

        System.out.println(numeros);
        System.out.println(palabras);

        for (Map.Entry<Integer, String> entry : personas.entrySet()) {
            System.out.println("DNI: " + entry.getKey() + " Nombre: " + entry.getValue());
        }
        System.out.println("Valores numericos mostrados con iterador");
        Iterator iterator = numeros.iterator();
        while (iterator.hasNext()) {
            System.out.print("[" + iterator.next() + "]");
        }
        System.out.println("");

        System.out.println("Metodo iterador remove()");
        ArrayList<String> bebidas = new ArrayList();
        bebidas.add("café");
        bebidas.add("té");
        System.out.println(bebidas);
        Iterator<String> it = bebidas.iterator();
        while (it.hasNext()) {
            if (it.next().equals("café")) {
                it.remove();
            }

        }
        System.out.println("-----------");
        System.out.println(bebidas);

        System.out.println("-----------");
        System.out.println("Titulos de libros (Orddenados por Año)");

        Libros libro1 = new Libros("Game of Thrones", "1996");
        Libros libro2 = new Libros("Lord of The Rings", "1937");
        ArrayList<Libros> titulos = new ArrayList();
        titulos.add(libro1);
        titulos.add(libro2);
        titulos.sort(Libros.compararAño);
        
        
        for (Libros ejemplar : titulos) {
            System.out.println(ejemplar);
        }

    }

}
