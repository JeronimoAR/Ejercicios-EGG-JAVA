package ejercicio_2;

import java.util.*;

public class Ejercicio_2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("/");
        String op;
        boolean flag = true;
        ArrayList<String> Razas = new ArrayList();
        do {
            System.out.print("Ingrese una raza de perro:");
            op = sc.nextLine();
            Razas.add(op);
            System.out.print("Desea Seguir ingresando datos? (S/N)");
            op = sc.nextLine();
        } while (op.equalsIgnoreCase("s"));

        System.out.println("Razas ingresadas");
        System.out.println(Razas);
        Iterator it = Razas.iterator();

        System.out.println("Ingrese el nombre del perro a eliminar");
        op = sc.nextLine();
        while (it.hasNext()) {
            if (it.next().equals(op)) {
                it.remove();
                flag = true;
            } else {
                flag = false;
            }
        }
        
        if (flag) {
            System.out.println("El perro se elimino");
            Collections.sort(Razas);
            System.out.println(Razas);
        }else{
            System.out.println("El no se encontró");
            Collections.sort(Razas);
            System.out.println(Razas);
        }

    }

}
