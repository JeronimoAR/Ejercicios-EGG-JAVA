package extra_2;

import java.util.*;
import extra_2.Entidad.CantanteFamoso;

public class Extra_2 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        ArrayList<CantanteFamoso> cantantes = new ArrayList();
        for (int i = 0; i < 1; i++) {
            CantanteFamoso singer = new CantanteFamoso();
            System.out.print("Ingrese el nombre del cantante:");
            singer.setNombre(sc.next());
            System.out.print("Ingrese el disco mas vendido:");
            singer.setDiscoMasVendido(sc.next());
            cantantes.add(singer);
        }
        System.out.println("-----------------");
        System.out.println("Los cantantes ingresados son:");
        for (CantanteFamoso aux : cantantes) {
            System.out.println(aux);
        }

        int op;

        do {
            System.out.print(""
                    + "------------------------------\n"
                    + "----------:::Menu:::----------\n"
                    + "1.Agregar un cantante mas\n"
                    + "2.Mostrar todos los cantantes\n"
                    + "3.Eliminar un cantante\n"
                    + "4.Salir\n"
                    + "Ingrese una opcion: ");
            op = sc.nextInt();
            System.out.println("------------------------------");
            switch (op) {
                case 1:
                    CantanteFamoso aux = new CantanteFamoso();
                    System.out.print("Ingrese el nombre del cantante: ");
                    aux.setNombre(sc.next());
                    System.out.print("Ingrese el dico mas vendido: ");
                    aux.setDiscoMasVendido(sc.next());
                    cantantes.add(aux);
                    System.out.println("Cantante ingresado correctamente");
                    break;
                case 2:
                    for (CantanteFamoso cantaux : cantantes) {
                        System.out.println(cantaux);
                    }
                    break;
                case 3:
                    System.out.println("Ingrese el nombre del cantante a eliminar: ");
                    String nombre = sc.next();
                    for (int i = 0; i < cantantes.size(); i++) {
                        if (cantantes.get(i).getNombre().equalsIgnoreCase(nombre)) {
                            cantantes.remove(i);
                        }
                    }
                    break;
                case 4:
                    System.out.println("-----::Saliendo::-----");
                    break;
                default:
                    System.out.println("Numero ingresado no valido");
            }
        } while (op != 4);
        for(CantanteFamoso c1:cantantes){
            System.out.println(c1);
        }
    }

}
