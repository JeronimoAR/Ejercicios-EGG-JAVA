package extra_1;

import java.util.*;

public class Extra_1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        int valor;
        ArrayList<Integer> valores = new ArrayList();
        do {
            System.out.println("Ingrese -99 para detener el ingreso");
            System.out.print("Ingrese un valor:");
            valor = sc.nextInt();
            if (valor != -99) {
                valores.add(valor);
            }
        } while (valor != -99);
        valor = 0;
        System.out.println("Numero de valores leidos: " + valores.size());
        for (int i = 0; i < valores.size(); i++) {
            valor += valores.get(i);
        }
        System.out.println("La suma de los valores ingresados es: " + valor);
        System.out.println("La media de los valores es: " + (valor / valores.size()));
    }

}
