package extra_4;

import java.util.*;

public class Extra_4 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        HashMap<Integer, String> paises = new HashMap();
        String ciudad;
        int codigo;

        System.out.println("Ingresa 10 numeros postales y sus ciudades");
        for (int i = 0; i < 10; i++) {
            System.out.println("Ingresando la Ciudad numero " + i);
            ciudad = sc.next();
            System.out.println("Ingresa el numero postal de: " + ciudad);
            codigo = sc.nextInt();
            paises.put(codigo, ciudad);
        }
        System.out.println(".....................");
        System.out.println("Mostrando ciudades ingresados");

        for (Map.Entry<Integer, String> entry : paises.entrySet()) {
            System.out.println(entry.getValue() + " -" + entry.getKey());
        }
        
        System.out.println(".....................");
        System.out.println("Ingresa un codigo postal para ver su ciudad: ");
        codigo = sc.nextInt();
        if (paises.containsKey(codigo)) {
            System.out.println("La ciudad de este codigo es: " + paises.get(codigo));
        } else {
            System.out.println("El codigo postal ingresado no se encontró");
        }

        System.out.println(".....................");
        System.out.println("Mostrando ciudades");
        
        for (Map.Entry<Integer, String> entry : paises.entrySet()) {
            System.out.println(entry.getValue() + " -" + entry.getKey());
        }

        System.out.println("...................");
        System.out.println("Ingresa una ciudad nueva:");
        System.out.print("Ingresa el nombre de la ciudad: ");
        ciudad = sc.next();
        System.out.println("Ingresa el codigo postal de " + ciudad);
        codigo = sc.nextInt();
        paises.put(codigo, ciudad);

        System.out.println("Ingresa 3 ciudades para eliminar");
        int cont = 0;
        while (cont < 3) {
            System.out.println("Ingrese el nombre de la ciudad #" + cont);
            ciudad = sc.next();
            if (paises.containsValue(ciudad)) {
                codigo = sacarLLave(paises, ciudad);
                paises.remove(codigo);
                cont++;
                System.out.println("Pais eliminado correctamente");
            } else {
                System.out.println("Pais no encontrado");
            }
        }

        System.out.println(".....................");
        System.out.println("Mostrando ciudades");
        
        for (Map.Entry<Integer, String> entry : paises.entrySet()) {
            System.out.println(entry.getValue() + " -" + entry.getKey());
        }

    }

    public static <LLave, Valor> LLave sacarLLave(HashMap<LLave, Valor> map, Valor V) {
        for (Map.Entry<LLave, Valor> entry : map.entrySet()) {
            if (Objects.equals(V, entry.getValue())) {
                return entry.getKey();
            }

        }
        return null;
    }
}
