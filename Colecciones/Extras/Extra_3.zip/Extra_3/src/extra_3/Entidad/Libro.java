package extra_3.Entidad;

public class Libro {
    private String titulo,autor;
    private int ejempAct,ejemPrest;

    public Libro() {
    }

    public Libro(String titulo, String autor, int ejempAct, int ejemPrest) {
        this.titulo = titulo;
        this.autor = autor;
        this.ejempAct = ejempAct;
        this.ejemPrest = ejemPrest;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getEjempAct() {
        return ejempAct;
    }

    public void setEjempAct(int ejempAct) {
        this.ejempAct = ejempAct;
    }

    public int getEjemPrest() {
        return ejemPrest;
    }

    public void setEjemPrest(int ejemPrest) {
        this.ejemPrest = ejemPrest;
    }

    @Override
    public String toString() {
        return "El libro: " + titulo + ", Fue escrito por: " + autor + " Tiene " + ejempAct + " ejemplares disponibles y " + ejemPrest + " ejemplares prestados";
    }
    
    
}
