package extra_3.Servicio;

import extra_3.Entidad.Libro;
import java.util.*;

public class LibroServicio {

    Scanner sc = new Scanner(System.in).useDelimiter("\n");

    public boolean prestamo(HashSet<Libro> libros) {
        boolean flag = false;
        System.out.println("Ingrese el titulo del libro");
        String nombre = sc.next();
        Libro[] aux = new Libro[libros.size()];
        aux = (Libro[]) libros.toArray(aux);
        for (int i = 0; i < aux.length; i++) {
            if (aux[i].getTitulo().equalsIgnoreCase(nombre)) {
                if (aux[i].getEjempAct() > 0) {
                    aux[i].setEjemPrest(aux[i].getEjemPrest() + 1);
                    aux[i].setEjempAct(aux[i].getEjempAct() - 1);
                    flag = true;
                }
            }
        }
        libros.clear();
        for (int i = 0; i < aux.length; i++) {
            libros.add(aux[i]);
        }
        return flag;
    }
    public boolean devolucion(HashSet<Libro> libros){
        boolean flag = false;
        System.out.println("Ingrese el titulo del lubro a devolver");
        String nombre = sc.next();
        Libro[] aux = new Libro[libros.size()];
        aux = libros.toArray(aux);
        for (int i = 0; i < aux.length; i++) {
            if (aux[i].getTitulo().equalsIgnoreCase(nombre)) {
                if (aux[i].getEjemPrest() > 0) {
                    aux[i].setEjemPrest(aux[i].getEjemPrest()-1);
                    aux[i].setEjempAct(aux[i].getEjempAct()+1);
                    flag = true;
                }
            }
        }
        libros.clear();
        for (int i = 0; i < aux.length; i++) {
            libros.add(aux[i]);
        }
        return flag;
    }
    
    public void mostrar(HashSet<Libro> libros){
        for(Libro aux:libros){
            System.out.println(aux);
        }
    }
            
}
