package extra_3;

import java.util.*;
import extra_3.Entidad.Libro;
import extra_3.Servicio.LibroServicio;

public class Extra_3 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        LibroServicio obj = new LibroServicio();
        HashSet<Libro> libros = new HashSet();
        String op;
        int menu;
        do{
            Libro l = new Libro();
            System.out.println("Ingrese el titulo del libro:");
            l.setTitulo(sc.next());
            System.out.println("Ingrese el autor del libro:");
            l.setAutor(sc.next());
            System.out.println("Ingrese cuantos ejemplares tiene este libro:");
            l.setEjempAct(sc.nextInt());
            l.setEjemPrest(0);
            libros.add(l);
            System.out.println("Desea Ingresar otro libro?(S/N)");
            op = sc.next();
        }while(op.equalsIgnoreCase("s"));
        do{
            System.out.print(""
                    + "------------------\n"
                    + "-----::Menu::-----\n"
                    + "1.Prestamo\n"
                    + "2.Devolucion\n"
                    + "3.Mostrar\n"
                    + "4.Salir\n"
                    + "Elige una opcion");
            menu = sc.nextInt();
            System.out.println("------------------");
            switch(menu){
                case 1:
                    if (obj.prestamo(libros)) {
                        System.out.println("Libro prestado exitosamente");
                    }else{
                        System.out.println("Error en el prestamo, vuelve a intentar");
                    }
                    break;
                case 2:
                    if (obj.devolucion(libros)) {
                        System.out.println("Libro devuelto exitosamente");
                    }else{
                        System.out.println("Error en la devolucion, vuelve a intentar");
                    }
                    break;
                case 3:
                    obj.mostrar(libros);
                    break;
                case 4:
                    System.out.println("---::Saliendo::---");
                    System.out.println("------------------");
                    break;
                default:
                    System.out.println("Numero ingresado no valido");
            }
        }while(menu != 4);
    }
    
}
