package ejercicio_3.Servicio;

import java.util.*;
import ejercicio_3.Entidad.Alumno;

public class Servicio {

    Scanner sc = new Scanner(System.in).useDelimiter("\n");
    ArrayList<Integer> notas = new ArrayList();
    ArrayList<Alumno> alumnos = new ArrayList();
    String op, nombre;
    int media, n1, n2, n3;

    public void ingrsearAlumos() {
        do {
            System.out.println("Ingrese el nombre del alumnno");
            nombre = sc.next();
            System.out.println("Ingrese las 3 notas");
            notas.add(sc.nextInt());
            notas.add(sc.nextInt());
            notas.add(sc.nextInt());
            System.out.println("---Creando Alumno---");
            Alumno estu = new Alumno(nombre, notas);
            alumnos.add(estu);
            System.out.println("Desea Seguir ingresando Alumnos? (S/N)");
            op = sc.next();
        } while (op.equalsIgnoreCase("s"));
    }

    public void notaFinal() {
        do {
            System.out.println("Ingrese el nombre del alumno para ver su nota");
            Iterator<Alumno> it = alumnos.iterator();
            nombre = sc.next();
            int index = alumnos.indexOf(nombre) + 1;
            if (alumnos.get(index).getNombre().equalsIgnoreCase(nombre)) {
                n1 = alumnos.get(index).getNotas().get(0);
                n2 = alumnos.get(index).getNotas().get(1);
                n3 = alumnos.get(index).getNotas().get(2);
                media = (n1 + n2 + n3) / 3;
                System.out.println("La media del estudiante es: " + media);
            } else {
                System.out.println("No se encontro el alumno");
            }
            System.out.println("Desea Ver la nota de otro alumno?(S/N)");
            op = sc.next();
        } while (op.equalsIgnoreCase("s"));
        System.out.println("---Saliendo---");
    }

}
