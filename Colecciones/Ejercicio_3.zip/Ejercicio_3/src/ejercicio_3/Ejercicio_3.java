package ejercicio_3;

import ejercicio_3.Servicio.Servicio;

public class Ejercicio_3 {

    public static void main(String[] args) {
        Servicio met = new Servicio();
        met.ingrsearAlumos();
        met.notaFinal();
    }
    
}
