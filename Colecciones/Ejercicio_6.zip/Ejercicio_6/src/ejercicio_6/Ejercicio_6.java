package ejercicio_6;

import java.util.*;
import ejercicio_6.Services.Servicio;

public class Ejercicio_6 {

    public static void main(String[] args) {
        Servicio obj = new Servicio();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        int op;
        do{
            System.out.print(""
                    + "-------------------\n"
                    + "--------Menu-------\n"
                    + "1.Ingresar Producto\n"
                    + "2.Cambiar Precio\n"
                    + "3.Eliminar Producto\n"
                    + "4.Mostrar productos\n"
                    + "5.Salir\n"
                    + "Ingrese una opcion:");
            op = sc.nextInt();
            System.out.println("-------------------");
            switch(op){
                case 1:
                    obj.crearProducto();
                    break;
                case 2:
                    obj.modificarPrecio();
                    break;
                case 3:
                    obj.eliminarProducto();
                    break;
                case 4:
                    obj.mostrar();
                    break;
                case 5:
                    System.out.println("---Saliendo---");
                default:
                    System.out.println("Numero invalido");
            }
        }while(op != 5);
    }
    
}
