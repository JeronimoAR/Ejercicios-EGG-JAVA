package ejercicio_6.Services;

import ejercicio_6.Entidad.Productos;
import java.util.*;

public class Servicio {

    Scanner sc = new Scanner(System.in).useDelimiter("\n");
    HashMap<String,Double> productos = new HashMap();
    String producto, op;
    Double precio;

    public void crearProducto() {
        do {
            System.out.println("Ingrese el nombre del producto:");
            producto = sc.next();
            System.out.println("Ingrese el precio del producto:");
            precio = sc.nextDouble();
            Productos p = new Productos(producto, precio);
            productos.put(p.getProducto(), p.getPrecio());
            System.out.println("Desea Seguir ingresando productos? (S/N)");
            op = sc.next();
        } while (op.equalsIgnoreCase("s"));
    }
    
    public void modificarPrecio(){
        System.out.println("Ingrese el nombre del producto a modificar");
        producto = sc.nextLine();
        if (productos.containsKey(producto)) {
            System.out.println("Ingresa el nuevo valor de producto:");
            precio = sc.nextDouble();
            productos.replace(producto, precio);
        }else{
            System.out.println("El producto no se encontró");
        }
    }
    
    public void eliminarProducto(){
        System.out.println("Ingrese el nombre del producto a eliminar");
        producto = sc.nextLine();
        if (productos.containsKey(producto)) {
            productos.remove(producto);
            System.out.println("Producto eliminado Correctamente");
        }else{
            System.out.println("Producto no encotrado");
        }
    }

    public void mostrar(){
        productos.entrySet().stream().sorted(Map.Entry.comparingByValue()).forEach(entry -> System.out.println(entry.getKey() + " = " + entry.getValue()));
    }
    
}
