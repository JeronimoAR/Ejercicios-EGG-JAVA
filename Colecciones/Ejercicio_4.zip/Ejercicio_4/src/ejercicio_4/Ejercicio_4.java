package ejercicio_4;

import ejercicio_4.Service.Servicio;

public class Ejercicio_4 {

    public static void main(String[] args) {
        Servicio obj = new Servicio();
        obj.crearPeliculas();
        obj.mostrarPeliculas();
    }
    
}
