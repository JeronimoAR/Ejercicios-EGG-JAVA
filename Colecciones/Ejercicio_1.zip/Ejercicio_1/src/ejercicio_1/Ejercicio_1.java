package ejercicio_1;

import java.util.*;

public class Ejercicio_1 {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("/");
        String op;
        ArrayList<String> Razas = new ArrayList();
        do{
            System.out.print("Ingrese una raza de perro:");
            op = sc.nextLine();
            Razas.add(op);
            System.out.print("Desea Seguir ingresando datos? (S/N)");
            op = sc.nextLine();
        }while(op.equalsIgnoreCase("s"));
        
        System.out.println("Razas ingresadas");
        System.out.println(Razas);
        
    }
    
}
