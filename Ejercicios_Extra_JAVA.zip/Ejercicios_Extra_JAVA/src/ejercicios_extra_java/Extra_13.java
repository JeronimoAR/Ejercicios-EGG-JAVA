/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_13 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Ingresa el tamaño de la escalera");
        num = sc.nextInt();
        for (int i = 1; i < num+1; i++) {
            for (int j = 1; j < i+1; j++) {
                System.out.print(j+"");
            }
            System.out.println("");
        }
    }
}
