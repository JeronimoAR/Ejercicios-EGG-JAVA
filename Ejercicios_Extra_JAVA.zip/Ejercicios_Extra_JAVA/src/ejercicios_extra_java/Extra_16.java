/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_16 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Ingrese el numero de personas");
        num = sc.nextInt();
        String[] nombres = new String[num];
        String[] may = new String[num];
        int[] edad = new int[num];
        for (int i = 0; i < num; i++) {
            System.out.println("-------------------------------");
            System.out.println("Ingrese el nombre de la persona");
            nombres[i] = sc.next();
            System.out.println("Ingrese la edad de la persona");
            nombres[i] = nombres[i].concat(" que tiene ");
            edad[i] = sc.nextInt();
            nombres[i] = nombres[i].concat(edad[i]+"");
        }
        may = mayor(nombres,edad,num);
        for (int i = 0; i < num; i++) {
            System.out.println(nombres[i] + may[i]);
            System.out.println("----------------------");
        }
    }
    public static String[] mayor (String[] nombres,int[] edad,int num){
        String[] edades = new String[num];
        for (int i = 0; i < num; i++) {
            if(edad[i] >= 18) {
                edades[i] = " Es mayor de edad";
            }else{
                edades[i] = " Es menor de edad";
            }
        }
        return edades;
    }
}
