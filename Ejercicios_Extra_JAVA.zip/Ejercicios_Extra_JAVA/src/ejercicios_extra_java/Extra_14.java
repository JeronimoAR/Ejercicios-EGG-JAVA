/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_14 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int numF,hijos,edad,promedio = 0;
        System.out.println("Ingresa la cantidad de familias");
        numF = sc.nextInt();
        for (int i = 0; i < numF; i++) {
            System.out.println("Ingresa el numero de Hijos dde la familia " + (i+1));
            hijos = sc.nextInt();
            for (int j = 0; j < hijos; j++) {
                System.out.println("Ingresa la edad del hijo " + (j+1));
                edad = sc.nextInt();
                promedio += edad;
            }
            promedio = promedio/hijos;
        }
        System.out.println("El promedio de las edades de todas las familias es: " + promedio/numF);
    }
}

