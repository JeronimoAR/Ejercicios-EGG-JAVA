/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_24 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num,num1,num2,num3;
        System.out.println("Ingresa el maximo de la secuencia");
        num = sc.nextInt();
        num1 = 1;
        num2 = 1;
        System.out.print(num1 + "." + num2 + ".");
        for (int i = 0; i < num; i++) {
            num3 = num1 + num2;
            System.out.println(num3 + ".");
            num1 = num2;
            num2 = num3;
        }
        System.out.println("");
    }
}
