package ejercicios_extra_java;
import java.util.Scanner;
public class Extra_24 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num,num1,num2;
        System.out.println("Ingresa el maximo de la secuencia");
        num = sc.nextInt();
        int[] vector = new int[num];
        num1 = 1;
        num2 = 1;
        System.out.print(num1 + "." + num2 + ".");
        
        /* si pones como maximo de secuencia "1" te 
        mostrara los primeros dos pero ya lo hize y 
        lo estan descargando corriganlo ustedaes XD */
        
        for (int i = 2; i < num; i++) {
            vector[i] = num1 + num2;
            System.out.print(vector[i] + ".");
            num1 = num2;
            num2 = vector[i];
        }
        System.out.println("");
    }
}
