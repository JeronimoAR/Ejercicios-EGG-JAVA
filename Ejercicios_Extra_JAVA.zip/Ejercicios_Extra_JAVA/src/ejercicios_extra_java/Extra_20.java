/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;

/**
 *
 * @author jeron
 */
public class Extra_20 {
    public static void main(String[] args){ 
        int[] vector = new int[4];
        vector = RellenarVector(vector);
        MostrarVector(vector);
    }
    public static int[] RellenarVector(int[] vector){
        for (int i = 0; i < 4; i++) {
            vector[i] = (int)(Math.random()*10);
        }
        return vector;
    }
    public static void MostrarVector(int[] vector){
        for (int i = 0; i < 4; i++) {
            System.out.print("[" + vector[i] + "]");
        }
        System.out.println("");
    }
}
