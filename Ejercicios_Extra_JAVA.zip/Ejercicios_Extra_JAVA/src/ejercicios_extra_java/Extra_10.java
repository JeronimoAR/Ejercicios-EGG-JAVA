/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_10 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num1,num2,mul,n;
        num1 = (int)(Math.random()*10+1);
        num2 = (int)(Math.random()*10+1);
        mul = num1 * num2;
        do{
            System.out.println("Ingresa un numero para adivinar la multiplicacion secreta");
            n = sc.nextInt();
            if (n != mul) {
                System.out.println("--------------------------------");
                System.out.println("---Fallaste Vuelve a intentar---");
                System.out.println("--------------------------------");
            } else if (n == mul) {
                System.out.println("---Correcto---");
            }
        }while(n != mul); 
    }
}
