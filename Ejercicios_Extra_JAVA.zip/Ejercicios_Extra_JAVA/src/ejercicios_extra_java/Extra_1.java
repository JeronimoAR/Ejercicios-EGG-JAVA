/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int min,dia,hora;
        System.out.println("Ingresa los minutos");
        min = sc.nextInt();
        dia = (int) min/1440;
        hora = (int)((min%1440)/60);
        System.out.println("Eso son: " + dia + " dias y " + hora + " horas");
    }
    
}
