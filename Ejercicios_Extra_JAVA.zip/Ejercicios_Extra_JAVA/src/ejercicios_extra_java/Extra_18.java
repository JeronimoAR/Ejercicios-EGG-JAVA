/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_18 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num,suma = 0;
        System.out.println("Ingresa el tamaño del vector");
        num = sc.nextInt();
        int[] vector = new int[num];
        for (int i = 0; i < num; i++){
            System.out.println("Ingresa el valor en la posission " + i);
            vector[i] = sc.nextInt();
            suma += vector[i];
        }
        System.out.println("-----------");
        System.out.println("La suma de los datos ingresados al vector es: " + suma);
    }
}
