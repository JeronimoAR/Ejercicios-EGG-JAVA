/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_9 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num1,num2;
        int[] resultados;
        System.out.println("Ingresa el numero que vas a dividir");
        num1 = sc.nextInt();
        System.out.println("Ingresa el numero por el que se va a dividir");
        num2 = sc.nextInt();
        resultados = div(num1,num2);
        System.out.println("El residuo es: " + resultados[0] + " y el cosiente es: " + resultados[1] );
    }
    public static int[] div(int num1,int num2){
        int[] resultados = new int[2];
        int cosiente,resto;
        boolean flag = true;
        cosiente = 0;
        resto = num1;
        while(flag == true){
            if (resto < num2) {
                flag = false;
            }else{
                resto = num1 - num2;
                num1 = resto;
                cosiente++;
            }
        }
        resultados[0] = resto;
        resultados[1] = cosiente;
        return resultados;
    }
}

