/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_15 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int num,num1, num2;
        System.out.println("Ingresa dos numeros");
        num1 = sc.nextInt();
        num2 = sc.nextInt();
        num = operaciones(num1,num2,sc);
        System.out.println("El resultado de la operacion es: " + num);
    }

    public static int operaciones(int num1, int num2, Scanner sc) {
        int num;
        String op = "N";
        do {
            System.out.println("---MENU---");
            System.out.println("Eliga que hacer con los numeros");
            System.out.println("1.Sumar" + "\n" + "2.Restar" + "\n" + "3.Multiplicar" + "\n" + "4.Dividir" + "\n" + "5.Salir");
                    num = sc.nextInt();
            switch (num) {
                case 1:
                    num = num1 + num2;
                    break;
                case 2:
                    num = num1 - num2;
                    break;
                case 3:
                    num = num1 * num2;
                    break;
                case 4:
                    num = num1 / num2;
                    break;
                case 5:
                    System.out.println("Seguro quieres salir S/N");
                    op = sc.next();
                    op = op.toUpperCase();
                    break;
            }
        } while (op.equals("N"));
        return num;
    }
}
