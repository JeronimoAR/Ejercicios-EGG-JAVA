package ejercicios_extra_java;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_11 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int cont,num,resultado;
        cont = 1;
        System.out.println("Ingresa un numero");
        num = sc.nextInt();
        System.out.println();
        do{
            num = num/10;
            cont++;
        }while(num >= 10);
        System.out.println("Este numero tiene " + cont + " digitos");
    }
}
