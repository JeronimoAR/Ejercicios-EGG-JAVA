package ejercicios_extra_java;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_17 {
    public static void main(String[] main){
        Scanner sc = new Scanner(System.in);
        int num;
        boolean flag;
        System.out.println("Ingresa un numero vere si es primo");
        num = sc.nextInt();
        flag = primo(num);
        if (flag == true) {
            System.out.println("El numero es primo");
        }else{
            System.out.println("El numero no es primo");
        }
    }
    public static boolean primo(int num){
        boolean flag = true;
        int cont = 2;
        while(flag == true && cont < num){
            if (num % cont == 0) {
                flag = false;
            }else{
                cont++;
            }
        }
        return flag;
    }
}
