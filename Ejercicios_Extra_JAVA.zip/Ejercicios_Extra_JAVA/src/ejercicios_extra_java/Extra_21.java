/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
import java.text.DecimalFormat;
public class Extra_21 {

    public static void main(String[] args) {
        double[] vector = new double[10];
        DecimalFormat df = new DecimalFormat("#.0");
        Scanner sc = new Scanner(System.in);
        double int1, int2, prac1, prac2;
        int alumnos = 10,cont = 0,cont1 = 0;
        for (int i = 0; i < 10; i++) {
            int1 = 0;
            int2 = 0;
            prac1 = 0;
            prac2 = 0;
            System.out.println("--------------------------------");
            System.out.println("Ingresando las notas del alumno " + (i+1));
            System.out.print("Ingrese la nota de el primer trabajo practico evaluativo: ");
            prac1 = sc.nextDouble();
            System.out.print("Ingrese la nota de el segundo trabajo practico evaluativo: ");
            prac2 = sc.nextDouble();
            System.out.print("Ingrese la nota de el primer integrador: ");
            int1 = sc.nextDouble();
            System.out.print("Ingrese la nota de el segundo integrador: ");
            int2 = sc.nextDouble();
            prac1 *= 0.10;
            prac2 *= 0.15;
            int1 *= 0.25;
            int2 *= 0.50;
            vector[i] = (prac1 + prac2) + (int1 + int2);
        }
        for (int i = 0; i < 10; i++) {
            if(vector[i] >= 7){
                cont1++;
            }else{
                cont++;
            }
        }
        System.out.println("El numero de estudiantes aprobados es: " + cont1);
        System.out.println("El numero de estudiantes reprobados es: " + cont);
    }
}
