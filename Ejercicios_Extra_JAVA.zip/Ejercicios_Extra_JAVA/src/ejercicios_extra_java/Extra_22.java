/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_22 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n,m,suma = 0;
        System.out.println("Ingresa las filas de la matriz");
        n = sc.nextInt();
        System.out.println("Ingresa las columnas de la matriz");
        m = sc.nextInt();
        int[][] matriz = new int[n][m];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                matriz[i][j] = (int)(Math.random()*11);
                System.out.print("[" + matriz[i][j] + "]");
            }
            System.out.println("");
        }
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < m; j++) {
                suma += matriz[i][j];
            }
        }
        System.out.println("La suma de los valores de la matriz es: " + suma);
    }
}
