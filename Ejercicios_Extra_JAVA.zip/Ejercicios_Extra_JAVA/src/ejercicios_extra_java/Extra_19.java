/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class Extra_19 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num,num1;
        boolean flag = true;
        System.out.println("Ingresa el tamaño del vector");
        num1 = sc.nextInt();
        int[] vector1 = new int[num1];
        int[] vector2 = new int[num1];
        for (int i = 0; i < num1; i++) {
            vector1[i] = (int)(Math.random()*2);
            vector2[i] = (int)(Math.random()*2);
            System.out.print(vector1[i] + ":");
        }
        System.out.println("");
        for (int i = 0; i < num1; i++) {
            System.out.print(vector2[i] + ":");
        }
        System.out.println("");
        num = 0;
        while(flag == true && num < num1){
            if (vector1[num] != vector2[num]) {
                flag = false;
            }
            num++;
        }
        if (flag == true) {
            System.out.println("Los vectores son iguales");
        }else{
            System.out.println("Los vectores no son iguales");
        }
    }
}
