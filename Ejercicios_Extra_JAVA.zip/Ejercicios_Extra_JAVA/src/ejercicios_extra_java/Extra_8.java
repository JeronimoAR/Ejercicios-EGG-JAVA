/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicios_extra_java;

import java.util.Scanner;

/**
 *
 * @author jeron
 */
public class Extra_8 {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int n,pares,impares,i;
        i = 0;
        pares = 0;
        impares = 0;
        do{
            i++;
            System.out.println("Ingresa el numero " + i);
            n = sc.nextInt();
            if(n % 2 == 0){
                pares++;
            }else{
                impares++;
            }
            if(n % 5 == 0){
                System.out.println("El numero ingresado es multiplo de 5");
                System.out.println("---Saliendo---");
            }
        }while(n % 5 != 0);
        System.out.println("La cantidad de numeros leidos es: " + i);
        System.out.println("La cantidad de numeros pares es: " + pares);
        System.out.println("La cantitad de numeros impares es: " + impares);
    
    }
}
