/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manos.a.la.obra.pkg13;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class ManosALaObra13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String[] vector = new String[7];
        for (int i = 0; i < 7; i++){
            System.out.println("Ingresa el nombre de tu compañero " + (i + 1));
            vector[i] = sc.nextLine();
        }
        for (int i = 0; i < 7; i++){
            System.out.println(vector[i]);
        }
    }
    
}
