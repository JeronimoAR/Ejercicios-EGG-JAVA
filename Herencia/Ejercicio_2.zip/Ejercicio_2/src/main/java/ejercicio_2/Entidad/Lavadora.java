package ejercicio_2.Entidad;

import java.util.Scanner;

public class Lavadora extends Electrodomestico{
    private int capacidad;

    public Lavadora(int capacidad, String color, int precio, int peso, char consumo) {
        super(color, precio, peso, consumo);
        this.capacidad = capacidad;
    }

    public Lavadora() {
        
    }

    public int getCapacidad() {
        return capacidad;
    }

    public void setCapacidad(int capacidad) {
        this.capacidad = capacidad;
    }

    public void crearLavadora() {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        super.crearElectrodomestico(); 
        System.out.println("Ingrese La capacidad de la lavadora");
        setCapacidad(sc.nextInt());
        precioFinal();
    }

    @Override
    public void precioFinal() {
        super.precioFinal();
        if (getCapacidad() > 30) {
            setPrecio(getPrecio() + 500);
        }
        System.out.println("Precio ajustado en: " + getPrecio());
    }
    //Añadir toString
}
