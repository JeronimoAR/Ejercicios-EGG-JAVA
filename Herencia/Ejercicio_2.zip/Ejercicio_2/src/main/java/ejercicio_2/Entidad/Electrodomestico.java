package ejercicio_2.Entidad;

import java.util.Scanner;

abstract class Electrodomestico {

    private String color;
    private int precio, peso;
    private char consumo;

    public Electrodomestico(String color, int precio, int peso, char consumo) {
        this.color = verificarColor(color);
        this.precio = precio;
        this.peso = peso;
        this.consumo = veriicarChar(consumo);
    }

    public Electrodomestico() {
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = verificarColor(color);
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public int getPeso() {
        return peso;
    }

    public void setPeso(int peso) {
        this.peso = peso;
    }

    public char getConsumo() {
        return consumo;
    }

    public void setConsumo(char consumo) {
        this.consumo = veriicarChar(consumo);
    }

    private char veriicarChar(char consumo) {
        consumo = Character.toUpperCase(consumo);
        return switch (consumo) {
            case 'A' -> consumo;
            case 'B' -> consumo;
            case 'C' -> consumo;
            case 'D' -> consumo;
            case 'E' -> consumo;
            case 'F' -> consumo;
            default -> 'F';
        };
    }
    
    private String verificarColor(String color){
        color = color.toLowerCase();
        return switch(color){
            case "blanco" -> color;
            case "negro" -> color;
            case "rojo" -> color;
            case "azul" -> color;
            case "gris" -> color;
            default -> "blanco";
        };
    }
    
    public void crearElectrodomestico(){
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("""
                           Ingresa el color del electrodomestico: 
                           Blanco
                           Negro
                           Rojo
                           Azul
                           Gris
                           Si ingresas incorrectamente sera de color blanco:""");
        setColor(verificarColor(sc.next()));
        setPrecio(1000);
        System.out.println("Ingresa el peso del electrodomestico: ");
        setPeso(sc.nextInt());
        System.out.println("Ingresa el consumo Electrico con un caracter entre la A y la F: ");
        setConsumo(veriicarChar(sc.next().charAt(0)));
    }
    
    public void precioFinal(){
        switch(getConsumo()){
            case 'A' -> setPrecio(getPrecio() + 1000);
            case 'B' -> setPrecio(getPrecio() + 800);
            case 'C' -> setPrecio(getPrecio() + 600);
            case 'D' -> setPrecio(getPrecio() + 500);
            case 'E' -> setPrecio(getPrecio() + 300);
            case 'F' -> setPrecio(getPrecio() + 100);
        }
        
        if(getPeso() > 0 && getPeso() < 20){
            setPrecio(getPrecio() + 100);
        }else if (getPeso() > 19 && getPeso() < 50){
            setPrecio(getPrecio() + 500);
        }else if (getPeso() > 49 && getPeso() < 80){
            setPrecio(getPrecio() + 800);
        }else{
            setPrecio(getPrecio() + 1000);
        }
    }

}
