package ejercicio_2;

import ejercicio_2.Entidad.*;

public class Ejercicio_2 {

    public static void main(String[] args) {
        Lavadora lava1 = new Lavadora();
        Televisor tele1 = new Televisor();
        
        lava1.crearLavadora();
        System.out.println("----------------------");
        tele1.crearTelevisor();
        System.out.println("Precio total de la lavadora: " + lava1.getPrecio() + " Color: " + lava1.getColor() + " Consumo energetico de grado: " + lava1.getConsumo());
        System.out.println("Precio total de el televisor: " + tele1.getPrecio() + " Color: " + tele1.getColor() + " Consumo energetico de grado: " + tele1.getConsumo());
    }
}
