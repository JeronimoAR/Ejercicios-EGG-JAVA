package ejercicio_1;

import ejercicio_1.Entidad.*;

public class Ejercicio_1 {

    public static void main(String[] args) {
        Perro perro1 = new Perro("Helltaker", "Almas", "Cerbero", 1200);
        perro1.alimntarse();
        
        Perro perro2 = new Perro("chikito","hervivoro","Salchicha",4);
        perro2.alimntarse();
        
        Gato gato1 = new Gato("Michi", "Croquetas", "Siames", 6);
        gato1.alimntarse();
        
        Caballo caballo1 = new Caballo("Pistolas", "zanahoria", "Fino", 14);
        caballo1.alimntarse();
    }
}
