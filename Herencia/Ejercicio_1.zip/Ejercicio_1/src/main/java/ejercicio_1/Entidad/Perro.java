package ejercicio_1.Entidad;

public class Perro extends Animal {

    public Perro() {
    }

    public Perro(String nombre, String alimento, String raza, int edad) {
        super(nombre, alimento, raza, edad);
    }

    @Override
    public void alimntarse() {
        if (alimento.equalsIgnoreCase("carnivoro")) {
            System.out.println(nombre + " esta comiendo carne");
        }else if(alimento.equalsIgnoreCase("hervivoro")){
            System.out.println(nombre + " esta comiendo plantas");
        }else{
            System.out.println(nombre + " esta comiendo " + alimento);
        }
    }

}
