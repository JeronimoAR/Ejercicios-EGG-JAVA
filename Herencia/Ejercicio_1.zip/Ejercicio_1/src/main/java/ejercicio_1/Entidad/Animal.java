package ejercicio_1.Entidad;

abstract class Animal {
    public String nombre,alimento,raza;
    public int edad;

    public Animal() {
    }

    public Animal(String nombre, String alimento, String raza, int edad) {
        this.nombre = nombre;
        this.alimento = alimento;
        this.raza = raza;
        this.edad = edad;
    }
    
    public void alimntarse(){
        System.out.println("Ando comiendo mierda");
    }
}
