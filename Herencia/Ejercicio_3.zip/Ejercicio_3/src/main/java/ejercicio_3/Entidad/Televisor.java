package ejercicio_3.Entidad;

import java.util.Scanner;

public class Televisor extends Electrodomestico {

    private int resolucion;
    private boolean TDT;

    public Televisor() {

    }

    public Televisor(int resolucion, boolean TDT, String color, int precio, int peso, char consumo) {
        super(color, precio, peso, consumo);
        this.resolucion = resolucion;
        this.TDT = TDT;
    }

    public int getResolucion() {
        return resolucion;
    }

    public void setResolucion(int resolucion) {
        this.resolucion = resolucion;
    }

    public boolean isTDT() {
        return TDT;
    }

    public void setTDT(boolean TDT) {
        this.TDT = TDT;
    }

    public void crearTelevisor() {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        String op = "";
        super.crearElectrodomestico();
        System.out.println("Ingrese la resolucion en pulgadas del televisor: ");
        setResolucion(sc.nextInt());
        do {
            System.out.println("El Televisor tiene TDT? (S/N)");
            op = sc.next();
            if (op.equalsIgnoreCase("s")) {
                setTDT(true);
            } else if (op.equalsIgnoreCase("n")) {
                setTDT(false);
                op = "s";
            } else {
                System.out.println("Le tra ingresada no valida vuelva a intentar");
            }
        } while (!op.equalsIgnoreCase("s"));
        precioFinal();
    }

    @Override
    public void precioFinal() {
        super.precioFinal();
        if (getResolucion() >= 40) {
            setPrecio((int)(getPrecio() + getPrecio() * 0.3));
        }else if(isTDT()){
            setPrecio(getPrecio() + 500);
        }
    }
    //Añadir toString
}
