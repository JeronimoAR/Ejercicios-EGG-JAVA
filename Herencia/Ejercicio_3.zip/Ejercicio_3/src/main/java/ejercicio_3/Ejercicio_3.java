package ejercicio_3;

import java.util.*;
import ejercicio_3.Entidad.*;

public class Ejercicio_3 {

    public static void main(String[] args) {
        
        ArrayList<Electrodomestico> electrodos = new ArrayList();
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        int op;
        
         for (int i = 0; i < 4; i++) {
             System.out.println("Creando Electrodomestico #" + i);
             
             do{
                 System.out.println("Desea crear una 1.lavadora o un 2.televisor?: ");
                 op = sc.nextInt();
                 if(op == 1){
                     System.out.println("-----:::Creando lavadora:::-----");
                     Lavadora lava1 = new Lavadora();
                     lava1.crearLavadora();
                     electrodos.add(lava1);
                 }else if(op == 2){
                     System.out.println("-----:::Creando Televisor:::-----");
                     Televisor tele1 = new Televisor();
                     tele1.crearTelevisor();
                     electrodos.add(tele1);
                 }else{
                     System.out.println("-----:::Numero ingresado no valido:::----");
                     op = 4;
                 }
             }while(op > 2);
             
             System.out.println("-----:::Electrodomesticos ingresados: " + electrodos.size() + " :::-----");
        }
        int sumaPrecios = 0, precioTele = 0, precioLava = 0;
        for (int i = 0; i < electrodos.size(); i++) {
            if(electrodos.get(i) instanceof Lavadora){
                System.out.println("Lavadora color: " + electrodos.get(i).getColor() + " Precio: " + electrodos.get(i).getPrecio());
                precioLava = precioLava + electrodos.get(i).getPrecio();
            }else{
                System.out.println("Televisor color: " + electrodos.get(i).getColor() + " Precio: " + electrodos.get(i).getPrecio());
                precioTele = precioTele + electrodos.get(i).getPrecio();
            }
            sumaPrecios = sumaPrecios + electrodos.get(i).getPrecio();
        }
        
        System.out.println("-----------------------------------");
        System.out.println("El precio de los televisores es: " + precioTele);
        System.out.println("El precio de las lavadoras es: " + precioLava);
        System.out.println("El precio completo es: " + sumaPrecios);
    }
}
