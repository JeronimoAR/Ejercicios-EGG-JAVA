package extra_2.Entidad;

public class Polideportivo extends Edificio {

    private boolean techo;
    private String nombre;

    public Polideportivo() {

    }

    public Polideportivo(boolean techo, String nombre) {
        this.techo = techo;
        this.nombre = nombre;
    }

    public Polideportivo(boolean techo, String nombre, int ancho, int alto, int largo) {
        super(ancho, alto, largo);
        this.techo = techo;
        this.nombre = nombre;
    }

    public boolean isTecho() {
        return techo;
    }

    public void setTecho(boolean techo) {
        this.techo = techo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public void calcularSuperficie() {
        System.out.println("La superficie del edificio: " + getNombre() + " es: " + (getLargo()*getAncho()));
    }

    @Override
    public void calcularVolumen() {
        System.out.println("El volumen del edificio: " + getNombre() + " es: " + (getAlto() * getAncho() * getLargo()));
    }
    
}
