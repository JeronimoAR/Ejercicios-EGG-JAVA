package extra_2;

import extra_2.Servicio.EdificioServicio;

public class Extra_2 {

    public static void main(String[] args) {
        EdificioServicio service = new EdificioServicio();
        service.menu();
    }
}
