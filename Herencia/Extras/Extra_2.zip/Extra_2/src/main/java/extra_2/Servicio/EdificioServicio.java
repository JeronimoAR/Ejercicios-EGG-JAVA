package extra_2.Servicio;

import extra_2.Entidad.*;
import java.util.*;

public class EdificioServicio {

    Scanner sc = new Scanner(System.in).useDelimiter("\n");

    private ArrayList<Edificio> crearEdificios() {
        ArrayList<Edificio> edificios = new ArrayList();
        for (int i = 0; i < 4; i++) {
            System.out.println("Creando Edificio #" + (i + 1));
            if (i < 2) {
                Polideportivo ed1 = new Polideportivo();
                System.out.println("Ingrese el Alto del edificio: ");
                ed1.setAlto(sc.nextInt());
                System.out.println("Ingrese el ancho del edificio: ");
                ed1.setAncho(sc.nextInt());
                System.out.println("Ingrese el largo del edificio: ");
                ed1.setLargo(sc.nextInt());
                System.out.println("Ingreese si el edificio esta techado(S/N): ");
                String op = sc.next();
                if (op.equalsIgnoreCase("s")) {
                    ed1.setTecho(true);
                } else {
                    ed1.setTecho(false);
                }
                System.out.println("Ingrese el nombre del edificio");
                ed1.setNombre(sc.next());
                edificios.add(ed1);
            } else if (i > 1) {
                EdificioDeOficinas ed2 = new EdificioDeOficinas();
                System.out.println("Ingrese el Alto del edificio: ");
                ed2.setAlto(sc.nextInt());
                System.out.println("Ingrese el ancho del edificio: ");
                ed2.setAncho(sc.nextInt());
                System.out.println("Ingrese el largo del edificio: ");
                ed2.setLargo(sc.nextInt());
                System.out.println("Ingrese pisos tiene el edificio: ");
                ed2.setNumPisos(sc.nextInt());
                System.out.println("Ingrese cuantas oficinas tiene le edificio:");
                ed2.setNumOficinas(sc.nextInt());
                System.out.println("Ingrese cuantos empleados por oficina son: ");
                ed2.setNumEmpleadosXOficina(sc.nextInt());
                edificios.add(ed2);
            }
        }
        return edificios;
    }
    public void menu(){
        ArrayList<Edificio> edificios = crearEdificios();
        int contTecho = 0;
        for (int i = 0; i < 4; i++) {
            System.out.println("Edificio #" + (i+1));
            edificios.get(i).calcularSuperficie();
            edificios.get(i).calcularVolumen();
            if(edificios.get(i) instanceof Polideportivo){
                Polideportivo ed1Aux = (Polideportivo)edificios.get(i);
                if(ed1Aux.isTecho()){
                    contTecho++;
                }
            }else{
                EdificioDeOficinas ed2Aux = (EdificioDeOficinas)edificios.get(i);
                ed2Aux.calcularPer();
            }
            System.out.println("Hay " + (contTecho) + " Edificios techados");
            System.out.println("-----------------------");
        }
    }
}
