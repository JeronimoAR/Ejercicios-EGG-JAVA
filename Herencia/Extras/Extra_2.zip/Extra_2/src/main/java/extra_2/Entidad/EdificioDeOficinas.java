package extra_2.Entidad;

public class EdificioDeOficinas extends Edificio {

    private int numOficinas, numEmpleadosXOficina, numPisos;

    public EdificioDeOficinas() {
    }

    public EdificioDeOficinas(int numOficinas, int numEmpleadosXOficina, int numPisos) {
        this.numOficinas = numOficinas;
        this.numEmpleadosXOficina = numEmpleadosXOficina;
        this.numPisos = numPisos;
    }

    public EdificioDeOficinas(int numOficinas, int numEmpleadosXOficina, int numPisos, int ancho, int alto, int largo) {
        super(ancho, alto, largo);
        this.numOficinas = numOficinas;
        this.numEmpleadosXOficina = numEmpleadosXOficina;
        this.numPisos = numPisos;
    }

    public int getNumOficinas() {
        return numOficinas;
    }

    public void setNumOficinas(int numOficinas) {
        this.numOficinas = numOficinas;
    }

    public int getNumEmpleadosXOficina() {
        return numEmpleadosXOficina;
    }

    public void setNumEmpleadosXOficina(int numEmpleadosXOficina) {
        this.numEmpleadosXOficina = numEmpleadosXOficina;
    }

    public int getNumPisos() {
        return numPisos;
    }

    public void setNumPisos(int numPisos) {
        this.numPisos = numPisos;
    }

    @Override
    public void calcularSuperficie() {
        System.out.println("La superficie de la oficina es: " + (getLargo() * getAncho()));

    }

    @Override
    public void calcularVolumen() {
        System.out.println("El volumen de la oficina es: " + (getAlto() * getAncho() * getLargo()));
    }

    public void calcularPer() {
        System.out.println("La cantidad de personas en tu oficinas es: \n"
                + (getNumPisos() * (getNumOficinas() * getNumEmpleadosXOficina())) + " en total. \n"
                + (getNumOficinas() * getNumEmpleadosXOficina()) + " por piso.");
    }
    
}
