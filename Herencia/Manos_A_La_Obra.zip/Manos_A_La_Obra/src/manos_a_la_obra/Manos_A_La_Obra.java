package manos_a_la_obra;

import java.util.*;
import manos_a_la_obra.Entidad.*;

public class Manos_A_La_Obra {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        Animal animal = new Animal();
        Perro perro = new Perro();
        Gato gato = new Gato();

        ArrayList<Animal> animales = new ArrayList();

        animales.add(animal);
        animales.add(perro);
        animales.add(gato);

        System.out.println("---:Mostrar sonido de cada animal:---");
        for (Animal aux : animales) {
            System.out.println(aux.hacerRuido());
        }
        
        System.out.println("---:Creando personas:---");
        System.out.println("Cuantas personas desea crear?: ");
        int len = sc.nextInt();
        ArrayList<Persona> personas = new ArrayList();
        for (int i = 0; i < len; i++) {
            Persona p1 = new Persona();
            p1.crearObjeto();
            personas.add(p1);
        }
        
        System.out.println("---:Mostrando personas:---");
        for (Persona persona : personas) {
            System.out.println(persona);
        }
    }

}
