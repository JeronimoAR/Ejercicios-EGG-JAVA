package manos_a_la_obra.Entidad;

public interface Manos_a_La_Interfaz {
    public abstract void crearObjeto();
}
