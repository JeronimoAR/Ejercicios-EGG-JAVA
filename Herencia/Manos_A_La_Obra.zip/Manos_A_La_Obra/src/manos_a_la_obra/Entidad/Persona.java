package manos_a_la_obra.Entidad;

import java.util.*;

public class Persona implements Manos_a_La_Interfaz {
    
    private String nombre, apellido;
    private int edad;

    public Persona(String nombre, String apellido, int edad) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }

    public Persona() {
    }

    @Override
    public void crearObjeto() {
        Scanner sc = new Scanner(System.in).useDelimiter("\n");
        System.out.println("Ingrese nombre");
        this.nombre = sc.next();
        System.out.println("Ingrese apellido");
        this.apellido = sc.next();
        System.out.println("Ingrese edad");
        this.edad = sc.nextInt();
    }

    public String getNombre() {
        return nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public int getEdad() {
        return edad;
    }

    @Override
    public String toString() {
        return nombre + " " + apellido + " Tiene: " + edad + " años";
    }

}
