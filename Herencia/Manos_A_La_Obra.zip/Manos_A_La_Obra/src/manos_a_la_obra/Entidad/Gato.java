package manos_a_la_obra.Entidad;

public class Gato extends Animal {

    public Gato() {
    }

    public Gato(String nombre, String raza) {
        super(nombre, raza);
    }

    @Override
    public String hacerRuido() {
        return "MIAU MIAU";
    }
}
