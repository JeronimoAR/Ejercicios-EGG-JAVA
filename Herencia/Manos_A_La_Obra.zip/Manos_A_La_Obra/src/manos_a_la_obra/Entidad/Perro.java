package manos_a_la_obra.Entidad;

public class Perro extends Animal {

    public Perro() {
    }

    public Perro(String nombre, String raza) {
        super(nombre, raza);
    }

    @Override
    public String hacerRuido() {
        return "!GUAU! !GUAU!";
    }
}
