package manos_a_la_obra.Entidad;

public class Animal {

    protected String nombre, raza;

    public Animal() {
    }

    public Animal(String nombre, String raza) {
        this.nombre = nombre;
        this.raza = raza;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getRaza() {
        return raza;
    }

    public void setRaza(String raza) {
        this.raza = raza;
    }

    public String hacerRuido() {
        return "Hablando";
    }

}

