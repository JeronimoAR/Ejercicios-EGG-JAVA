package ejercicio_4.Entidad;

public interface CalculosFormas {
    public final double PI = 3.14;
    
    public double area();
    
    public double perimetro();
}
