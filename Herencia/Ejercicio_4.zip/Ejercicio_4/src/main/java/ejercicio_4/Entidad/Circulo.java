package ejercicio_4.Entidad;

public class Circulo implements CalculosFormas{

    private int radio;
    private int diametro;

    public Circulo(int radio) {
        this.diametro = 2*radio;
        this.radio = radio;
    }

    public int getRadio() {
        return radio;
    }

    public void setRadio(int radio) {
        this.radio = radio;
    }

    public int getDiametro() {
        return diametro;
    }

    @Override
    public double area(){
        return PI*Math.pow(radio,2);
    }
    
    @Override
    public double perimetro(){
        return PI * diametro;
    }
    
}
