package ejercicio_4;

import ejercicio_4.Entidad.*;

public class Ejercicio_4 {

    public static void main(String[] args) {
        System.out.println("-----::Creando rectangulo::----- ");
        Rectangulo rect = new Rectangulo(2,2);
        System.out.println("Rectangulo creado: Base: " + rect.getBase() + " Altura: " + rect.getAltura());
        System.out.println("Area del rectangulo: " + rect.area());
        System.out.println("Perimetro del Rectangulo: " + rect.perimetro());
        System.out.println("-----::Creando Circulo::----- ");
        Circulo circulo = new Circulo(2);
        System.out.println("Circulo creado: Radio: " + circulo.getRadio());
        System.out.println("Diametro del Circulo: " + circulo.getDiametro());
        System.out.println("Area del Circulo: " + circulo.area());
        System.out.println("Perimetro del Circulo: " + circulo.perimetro());
    }
}
