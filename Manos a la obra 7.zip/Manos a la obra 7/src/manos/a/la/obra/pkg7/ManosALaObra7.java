/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package manos.a.la.obra.pkg7;
import java.util.Scanner;
/**
 *
 * @author jeron
 */
public class ManosALaObra7 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int num;
        System.out.println("Ingrese el tipo de bomba que tiene");
        num = sc.nextInt();
        switch (num){
            case 1:
                System.out.println("Tienes una bomba de agua");
                break;
            case 2:
                System.out.println("Tienes una bomba de gasolina");
                break;
            case 3:
                System.out.println("Tienes una bomba de concreto");
                break;
            case 4:
                System.out.println("Tienes una bomba de pasta alimenticia");
                break;
            default:
                System.out.println("No existe ningun valor valido para este tipo de bomba");           
        }
    }
    
}
